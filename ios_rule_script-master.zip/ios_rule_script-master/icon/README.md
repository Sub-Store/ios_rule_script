# 图标

本目录中的文件为上游仓库的单向备份，主要为解决原作者删除图片后，导致引用的图片链接失效问题。

**图片版权属于原作者及商标所属的个人/组织。如果你喜欢这些图片，请根据README中的说明，给原作者的仓库一个Star⭐！**

**强烈建议使用原作者的图片链接，以获得及时的更新，这里只作为备份。**

备份由程序自动进行，只增不删，不对备份内容进行审核，同时也无法对备份内容合法性负责。

https://github.com/blackmatrix7/ios_rule_script/tree/master/icon/mini 备份自 https://github.com/Orz-3/mini/tree/master/Alpha    

https://github.com/blackmatrix7/ios_rule_script/tree/master/icon/color 备份自 https://github.com/Orz-3/mini/tree/master/Color

https://github.com/blackmatrix7/ios_rule_script/tree/master/icon/qure 备份自 https://github.com/Koolson/Qure/tree/master/IconSet

https://github.com/blackmatrix7/ios_rule_script/tree/master/icon/dark 备份自 https://github.com/Koolson/Qure/tree/master/IconSet/Dark

https://github.com/blackmatrix7/ios_rule_script/tree/master/icon/qure/color 备份自 https://github.com/Koolson/Qure/tree/master/IconSet/Color

https://github.com/blackmatrix7/ios_rule_script/tree/master/icon/task 备份自 https://github.com/Orz-3/task   (上游已删库，不再更新)







